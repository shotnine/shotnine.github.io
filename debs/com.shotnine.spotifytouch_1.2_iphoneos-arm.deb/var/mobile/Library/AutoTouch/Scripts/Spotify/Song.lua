CREATETIME="2018-08-09 17:23:37";

local color = getColor(524.48, 193.88);
lscolor = 1184274;
if color ~= lscolor then
repeat
usleep(10000);
local color = getColor(524.48, 193.88);
until color == lscolor;
end

usleep(1*1000*1000)
tap(363.34, 198.97);
usleep(10000);
tap(385.92, 1200);
