CREATETIME="2018-08-09 17:13:00";

local color = getColor(585.04, 191.85);
lscolor = 1184274;
if color ~= lscolor then
repeat
usleep(10000);
local color = getColor(585.04, 191.85);
until color == lscolor
end

usleep(1*1000*1000)
tap(585.04, 191.85)

local color = getColor(241.20, 666.31);
lscolor = 1947988;
if color ~= lscolor then
repeat
usleep(100000);
local color = getColor(241.20, 666.31);
until color == lscolor
end

usleep(1*1000*1000);
tap(241.20, 666.31);

usleep(1*1000*1000);
tap(385.92, 1200);


