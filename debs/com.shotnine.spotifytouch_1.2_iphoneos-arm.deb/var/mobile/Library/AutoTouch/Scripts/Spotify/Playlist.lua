CREATETIME="2018-08-09 18:35:10";

usleep(50000)
local color = getColor(380.79, 604.20);
lscolor = 1184274;
if color ~= lscolor then
repeat
usleep(10000);
local color = getColor(380.79, 604.20);
until color == lscolor
end

usleep(1*1000*1000)
tap(211.43, 352.72)

local color = getColor(295.60, 701.93);
local colore = getColor(391.06, 177.60);
lscolor = 1947988;
if color ~= lscolor and colore ~= lscolor then
repeat
usleep(100000);
local color = getColor(295.60, 701.93);
local colore = getColor(391.06, 177.60);
until color == lscolor or colore == lscolor
end

local color = getColor(295.60, 701.93);
local colore = getColor(391.06, 177.60);

if color == lscolor then
usleep(1*1000*1000);
tap(295.60, 701.93)
elseif colore == lscolor then
usleep(1*1000*1000);
tap(385.92, 169.46)
else
end

usleep(1.25*1000*1000)
tap(383.87, 1199.80)





