CREATETIME="2018-08-09 16:30:20";

usleep(2*1000*1000)
local color = getColor(524.48, 193.88);
lscolor = 1184274;
if color ~= lscolor then
repeat
usleep(10000);
local color = getColor(524.48, 193.88);
until color == lscolor
end

usleep(1*1000*1000)
tap(550.14, 193.88)

local color = getColor(230.93, 736.55);
lscolor = 1947988;
if color ~= lscolor then
repeat
usleep(100000);
local color = getColor(230.93, 736.55);
until color == lscolor
end

usleep(300000)
tap(480, 1005);

usleep(300000);
tap(385.92, 1192.67);









